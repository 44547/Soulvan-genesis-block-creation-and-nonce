const tabs = [
  { key: 'mining', label: 'Mining' },
  { key: 'wallet', label: 'Wallet' },
  { key: 'musicai', label: 'SoulvanMusic AI' },
  { key: 'photoai', label: 'PhotoAI Avatars' },
  { key: 'dao', label: 'DAO Governance' },
  { key: 'scripts', label: 'Utility Scripts' },
  { key: 'tests', label: 'Tests' },
  { key: 'docker', label: 'Docker' }
];

let selected = 'mining';

let miningState = {
  runningId: null,
  external: false,
  stats: { hashrate: 0, shares: 0, accepted: 0, rejected: 0, uptimeSec: 0 },
  coin: 'soulvan',
  mode: 'solo',
  address: '',
  engine: 'external',
  exePath: '',
  presetId: 'xmrig',
  poolUrl: '',
  password: 'x',
  threads: '',
  extraArgs: '',
  logs: []
};

let walletState = {
  coin: 'soulvan',
  address: '',
  balance: null,
  newWallet: null,
  send: { to: '', amount: '' }
};

let daoState = { proposals: [] };
let testOutput = '';
let diagOutput = '';
let benchOutput = '';
let presets = { presets: [] };

function render() {
  const root = document.getElementById('root');
  root.innerHTML = `
    <div class="navbar">
      ${tabs.map(tab => `
        <span class="tab${selected === tab.key ? ' selected' : ''}" data-key="${tab.key}">
          ${tab.label}
        </span>`).join('')}
      <span style="margin-left:auto"></span>
      <button id="theme-cycle" title="Cycle Cinematic Theme">Theme</button>
    </div>
    <div class="tab-content">
      ${getTabContent(selected)}
    </div>
  `;
  Array.from(document.querySelectorAll('.tab')).forEach(el => {
    el.onclick = () => { selected = el.dataset.key; render(); };
  });
  document.getElementById('theme-cycle').onclick = () => {
    const next = window.CinematicTheme.cycle();
    console.log('Theme changed to:', next);
  };
  wireTab(selected);
}

function getTabContent(tab) {
  switch(tab) {
    case 'mining': return miningTab();
    case 'wallet': return walletTab();
    case 'musicai': return musicAITab();
    case 'photoai': return photoAITab();
    case 'dao': return daoTab();
    case 'scripts': return scriptsTab();
    case 'tests': return testsTab();
    case 'docker': return dockerTab();
    default: return `<p>Coming soon.</p>`;
  }
}

function miningTab() {
  const s = miningState;
  const preset = (presets.presets || []);
  return `
    <div class="card">
      <div class="row">
        <label>Engine</label>
        <select id="mining-engine">
          <option value="external"${s.engine==='external'?' selected':''}>External Miner</option>
          <option value="builtin"${s.engine==='builtin'?' selected':''}>Built-in (Demo)</option>
        </select>
        <label>Coin</label>
        <select id="mining-coin">
          <option value="soulvan"${s.coin==='soulvan'?' selected':''}>Soulvan</option>
          <option value="ton"${s.coin==='ton'?' selected':''}>TON</option>
        </select>
        <label>Mode</label>
        <select id="mining-mode">
          <option value="solo"${s.mode==='solo'?' selected':''}>Solo</option>
          <option value="pool"${s.mode==='pool'?' selected':''}>Pool</option>
        </select>
      </div>
      ${s.engine === 'external' ? `
      <div class="row">
        <label>Preset</label>
        <select id="mining-preset">${preset.map(p => `<option value="${p.id}"${s.presetId===p.id?' selected':''}>${p.name}</option>`).join('')}</select>
        <input id="mining-exe" placeholder="Miner exe path (e.g., C:\\\\miners\\\\xmrig\\\\xmrig.exe)" size="52" value="${s.exePath || ''}"/>
      </div>
      <div class="row">
        <input id="mining-pool" placeholder="Pool URL (e.g., stratum+tcp://pool.example:3333)" size="48" value="${s.poolUrl || ''}"/>
        <input id="mining-wallet" placeholder="Wallet address/username" size="40" value="${s.address || ''}"/>
      </div>
      <div class="row">
        <input id="mining-password" placeholder="Password (default x)" size="16" value="${s.password || 'x'}"/>
        <input id="mining-threads" placeholder="Threads (optional)" size="12" value="${s.threads || ''}"/>
        <input id="mining-extra" placeholder="Extra args (optional)" size="40" value="${s.extraArgs || ''}"/>
      </div>` : `
      <div class="row">
        <input id="mining-wallet" placeholder="Wallet address" size="48" value="${s.address || ''}"/>
      </div>`}
      <div class="row">
        <button id="mining-start" ${s.runningId ? 'disabled':''}>Start</button>
        <button id="mining-stop" ${!s.runningId ? 'disabled':''}>Stop</button>
      </div>
    </div>
    <div class="card">
      <h3>Stats</h3>
      <div class="mono">
        Hashrate: ${s.stats.hashrate ? s.stats.hashrate.toFixed(2) : 0} H/s<br/>
        Shares: ${s.stats.shares} (✓ ${s.stats.accepted} / ✗ ${s.stats.rejected})<br/>
        Uptime: ${s.stats.uptimeSec || 0}s
      </div>
    </div>
    ${s.engine === 'external' ? `
    <div class="card">
      <h3>Miner Logs</h3>
      <pre id="mining-logs" class="mono" style="max-height:280px;overflow:auto;white-space:pre-wrap;">${(s.logs || []).join('\n')}</pre>
    </div>` : ''}
  `;
}

function walletTab() {
  const w = walletState;
  const knownUser = Boolean(localStorage.getItem('sv_known_user'));
  return `
    <div class="card">
      <div class="row">
        <label>Coin</label>
        <select id="wallet-coin">
          <option value="soulvan"${w.coin==='soulvan'?' selected':''}>Soulvan</option>
          <option value="ton"${w.coin==='ton'?' selected':''}>TON</option>
        </select>
        <input id="wallet-address" placeholder="Address" size="42" value="${w.address || ''}" />
        <button id="wallet-get-balance">Get Balance</button>
        <button id="wallet-create">Create Wallet</button>
        <button id="wallet-cinematic-onboard">Cinematic Onboarding</button>
      </div>
      <div>Balance: <span class="mono">${w.balance === null ? '-' : w.balance}</span></div>
      ${w.newWallet ? `
        <div class="card">
          <div>New Wallet Address: <span class="mono">${w.newWallet.address}</span></div>
          <div>Private Key (DEMO ONLY): <span class="mono">${w.newWallet.privateKey}</span></div>
        </div>` : ''}
      ${!knownUser ? `<div class="cine-pill">Tip: New here? Try "Cinematic Onboarding".</div>` : ''}
    </div>
    <div class="card">
      <h3>Send</h3>
      <div class="row">
        <input id="wallet-send-to" placeholder="Recipient address" size="42" value="${w.send.to || ''}" />
        <input id="wallet-send-amount" placeholder="Amount" size="10" value="${w.send.amount || ''}" />
        <button id="wallet-send-btn">Send</button>
      </div>
    </div>
  `;
}

function musicAITab() {
  return `
    <div class="card">
      <h3>SoulvanMusic AI</h3>
      <textarea id="music-prompt" rows="3" placeholder="Describe the music to generate (style, mood, tempo)"></textarea>
      <div class="row">
        <input id="music-length" type="number" value="8" min="1" max="60" /> <span>seconds</span>
        <button id="music-generate">Generate</button>
      </div>
      <div id="music-result" class="mono"></div>
    </div>
  `;
}

function photoAITab() {
  return `
    <div class="card">
      <h3>PhotoAI Avatars</h3>
      <div class="row">
        <input id="photo-path" placeholder="Path to image file" size="50" />
        <select id="photo-style">
          <option value="cyberpunk">Cyberpunk</option>
          <option value="cartoon">Cartoon</option>
          <option value="oil-painting">Oil Painting</option>
        </select>
        <button id="photo-generate">Generate Avatar</button>
      </div>
      <div id="photo-result" class="mono"></div>
    </div>
  `;
}

function daoTab() {
  const rows = (daoState.proposals || []).map(p => `
    <div class="card">
      <div><strong>${p.title}</strong> — <span class="mono">#${p.id}</span></div>
      <div>${p.description}</div>
      <div class="row">
        <button data-vote="${p.id}" data-choice="yes">Vote YES (${p.votes.yes})</button>
        <button data-vote="${p.id}" data-choice="no">Vote NO (${p.votes.no})</button>
      </div>
    </div>
  `).join('');
  return `
    <div class="card">
      <h3>Create Proposal</h3>
      <input id="dao-title" placeholder="Title" size="40" />
      <br/>
      <textarea id="dao-desc" rows="3" placeholder="Description"></textarea>
      <br/>
      <button id="dao-create">Create</button>
    </div>
    <h3>Proposals</h3>
    ${rows || '<div class="card">No proposals yet.</div>'}
  `;
}

function scriptsTab() {
  return `
    <div class="card">
      <h3>Diagnostics</h3>
      <button id="run-diagnostics">Run Diagnostics</button>
      <pre class="mono" id="diag-output">${diagOutput || ''}</pre>
    </div>
    <div class="card">
      <h3>Benchmark</h3>
      <div class="row">
        <input id="bench-seconds" type="number" min="1" max="60" value="5" /> <span>seconds</span>
        <button id="run-benchmark">Run</button>
      </div>
      <pre class="mono" id="bench-output">${benchOutput || ''}</pre>
    </div>
  `;
}

function testsTab() {
  return `
    <div class="card">
      <h3>Tests</h3>
      <button id="run-tests">Run Tests</button>
      <pre class="mono" id="test-output">${testOutput || ''}</pre>
    </div>
  `;
}

function dockerTab() {
  return `
    <div class="card">
      <h3>Docker</h3>
      <div class="row">
        <input id="docker-tag" placeholder="image tag (e.g., soulvancoin-app:dev)" size="32"/>
        <button id="docker-build">Build</button>
        <button id="docker-run">Run</button>
      </div>
      <div>Requires Docker installed on your system.</div>
    </div>
  `;
}

function wireTab(tab) {
  if (tab === 'mining') {
    if (!presets.presets?.length) {
      window.api.mining.presets().then(p => { presets = p; render(); });
    }
    document.getElementById('mining-engine').onchange = (e) => { miningState.engine = e.target.value; render(); };
    document.getElementById('mining-coin').onchange = (e) => miningState.coin = e.target.value;
    document.getElementById('mining-mode').onchange = async (e) => {
      miningState.mode = e.target.value;
      await window.api.mining.setMode(miningState.mode, { poolUrl: miningState.poolUrl });
    };
    const w = document.getElementById('mining-wallet');
    if (w) w.oninput = (e) => miningState.address = e.target.value;

    const psel = document.getElementById('mining-preset');
    if (psel) psel.onchange = (e) => miningState.presetId = e.target.value;

    const exe = document.getElementById('mining-exe');
    if (exe) exe.oninput = (e) => miningState.exePath = e.target.value;

    const pool = document.getElementById('mining-pool');
    if (pool) pool.oninput = (e) => miningState.poolUrl = e.target.value;

    const pwd = document.getElementById('mining-password');
    if (pwd) pwd.oninput = (e) => miningState.password = e.target.value;

    const th = document.getElementById('mining-threads');
    if (th) th.oninput = (e) => miningState.threads = e.target.value;

    const extra = document.getElementById('mining-extra');
    if (extra) extra.oninput = (e) => miningState.extraArgs = e.target.value;

    document.getElementById('mining-start').onclick = async () => {
      miningState.logs = [];
      const { id, external } = await window.api.mining.start({
        engine: miningState.engine,
        coin: miningState.coin,
        mode: miningState.mode,
        address: miningState.address || '',
        presetId: miningState.presetId,
        exePath: miningState.exePath,
        poolUrl: miningState.poolUrl,
        password: miningState.password,
        threads: miningState.threads,
        extraArgs: miningState.extraArgs
      });
      miningState.runningId = id;
      miningState.external = external;
      window.api.mining.onStats((evt) => {
        if (evt.id === miningState.runningId) {
          miningState.stats = evt;
          if (selected === 'mining') render();
        }
      });
      window.api.mining.onLog((evt) => {
        if (evt.id === miningState.runningId) {
          miningState.logs.push(evt.line);
          if (miningState.logs.length > 500) miningState.logs.shift();
          const el = document.getElementById('mining-logs');
          if (el) {
            el.textContent = miningState.logs.join('\n');
            el.scrollTop = el.scrollHeight;
          }
        }
      });
      window.api.mining.onEvent((evt) => {
        if (evt.type === 'exit' && evt.id === miningState.runningId) {
          miningState.runningId = null;
          render();
        }
      });
      render();
    };

    document.getElementById('mining-stop').onclick = async () => {
      await window.api.mining.stop(miningState.runningId, miningState.external);
      miningState.runningId = null;
      miningState.stats = { hashrate: 0, shares: 0, accepted: 0, rejected: 0, uptimeSec: 0 };
      render();
    };
  }

  if (tab === 'wallet') {
    document.getElementById('wallet-coin').onchange = (e) => walletState.coin = e.target.value;
    document.getElementById('wallet-address').oninput = (e) => walletState.address = e.target.value;
    document.getElementById('wallet-get-balance').onclick = async () => {
      const res = await window.api.wallet.getBalance(walletState.coin, walletState.address);
      walletState.balance = res.balance ?? res;
      render();
    };
    document.getElementById('wallet-create').onclick = async () => {
      const res = await window.api.wallet.create(walletState.coin);
      walletState.newWallet = res;
      walletState.address = res.address;
      render();

      const wasKnown = Boolean(localStorage.getItem('sv_known_user'));
      localStorage.setItem('sv_known_user', '1');
      if (!wasKnown) {
        window.CinematicTheme.cycle();
        window.WalletInterrogation.start({ mode: 'create', newWallet: res });
      } else {
        window.CinematicTheme.transitionTo(window.CinematicTheme.get(), { duration: 500 });
      }
    };
    document.getElementById('wallet-cinematic-onboard').onclick = () => {
      window.WalletInterrogation.start({ mode: 'create', newWallet: walletState.newWallet || null });
    };
    document.getElementById('wallet-send-to').oninput = (e) => walletState.send.to = e.target.value;
    document.getElementById('wallet-send-amount').oninput = (e) => walletState.send.amount = e.target.value;
    document.getElementById('wallet-send-btn').onclick = async () => {
      const res = await window.api.wallet.send(walletState.coin, walletState.address, walletState.send.to, Number(walletState.send.amount));
      alert(res.ok ? 'Transaction sent (demo)' : `Failed: ${res.error || 'unknown'}`);
    };
  }

  if (tab === 'musicai') {
    document.getElementById('music-generate').onclick = async () => {
      const prompt = document.getElementById('music-prompt').value;
      const lengthSec = Number(document.getElementById('music-length').value);
      const res = await window.api.ai.musicGenerate(prompt, lengthSec);
      const link = res.filePath ? `Saved to: ${res.filePath}` : '';
      document.getElementById('music-result').textContent = JSON.stringify({ ...res, note: link }, null, 2);
    };
  }

  if (tab === 'photoai') {
    document.getElementById('photo-generate').onclick = async () => {
      const imagePath = document.getElementById('photo-path').value;
      const style = document.getElementById('photo-style').value;
      const res = await window.api.ai.photoAvatar(imagePath, style);
      document.getElementById('photo-result').textContent = JSON.stringify(res, null, 2);
    };
  }

  if (tab === 'dao') {
    const refresh = async () => {
      daoState.proposals = await window.api.dao.list();
      render();
    };
    document.getElementById('dao-create').onclick = async () => {
      const title = document.getElementById('dao-title').value;
      const desc = document.getElementById('dao-desc').value;
      await window.api.dao.create(title, desc);
      await refresh();
    };
    document.querySelectorAll('[data-vote]').forEach(btn => {
      btn.onclick = async () => {
        const id = Number(btn.getAttribute('data-vote'));
        const choice = btn.getAttribute('data-choice');
        await window.api.dao.vote(id, choice);
        await refresh();
      };
    });
    refresh();
  }

  if (tab === 'scripts') {
    document.getElementById('run-diagnostics').onclick = async () => {
      const res = await window.api.scripts.diagnostics();
      diagOutput = JSON.stringify(res, null, 2);
      render();
    };
    document.getElementById('run-benchmark').onclick = async () => {
      const seconds = Number(document.getElementById('bench-seconds').value);
      const res = await window.api.scripts.benchmark(seconds);
      benchOutput = JSON.stringify(res, null, 2);
      render();
    };
  }

  if (tab === 'tests') {
    document.getElementById('run-tests').onclick = async () => {
      testOutput = 'Use "npm run tests" in a terminal to execute tests. (See tests/miner_tests.js)';
      render();
    };
  }

  if (tab === 'docker') {
    document.getElementById('docker-build').onclick = async () => {
      const tag = document.getElementById('docker-tag').value || 'soulvancoin-app:dev';
      const res = await window.api.docker.build(tag);
      alert(res.ok ? 'Build started/completed (see logs in terminal)' : `Build failed: ${res.error}`);
    };
    document.getElementById('docker-run').onclick = async () => {
      const tag = document.getElementById('docker-tag').value || 'soulvancoin-app:dev';
      const res = await window.api.docker.run(tag, []);
      alert(res.ok ? 'Container run started (see terminal)' : `Run failed: ${res.error}`);
    };
  }
}

window.onload = () => {
  window.api.mining.presets().then(p => { presets = p; render(); });
};