(function () {
  // Simple particle background
  function createFX(canvas) {
    const ctx = canvas.getContext('2d');
    let w = canvas.width = canvas.clientWidth;
    let h = canvas.height = canvas.clientHeight;
    let raf;
    const stars = Array.from({ length: 120 }, () => ({
      x: Math.random() * w,
      y: Math.random() * h,
      z: Math.random() * 1 + 0.5,
      r: Math.random() * 1.2 + 0.2,
      vx: (Math.random() - 0.5) * 0.15,
      vy: (Math.random() - 0.5) * 0.15
    }));

    function resize() {
      w = canvas.width = canvas.clientWidth;
      h = canvas.height = canvas.clientHeight;
    }
    window.addEventListener('resize', resize);

    function tick() {
      ctx.clearRect(0, 0, w, h);
      ctx.globalCompositeOperation = 'lighter';
      for (const s of stars) {
        s.x += s.vx * s.z;
        s.y += s.vy * s.z;
        if (s.x < -10) s.x = w + 10;
        if (s.x > w + 10) s.x = -10;
        if (s.y < -10) s.y = h + 10;
        if (s.y > h + 10) s.y = -10;
        const g = ctx.createRadialGradient(s.x, s.y, 0, s.x, s.y, 18 * s.z);
        g.addColorStop(0, 'rgba(255,255,255,0.08)');
        g.addColorStop(1, 'rgba(255,255,255,0)');
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(s.x, s.y, 20 * s.z, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,0.7)';
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
        ctx.fill();
      }
      raf = requestAnimationFrame(tick);
    }
    tick();

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', resize);
    };
  }

  function typewriter(el, text, speed = 12) {
    return new Promise((resolve) => {
      el.textContent = '';
      let i = 0;
      function step() {
        if (i <= text.length) {
          el.textContent = text.slice(0, i);
          i++;
          setTimeout(step, Math.max(4, 1000 / speed));
        } else {
          resolve();
        }
      }
      step();
    });
  }

  const THEMES = ['neo', 'aurora', 'noir', 'sunset'];

  const CinematicTheme = {
    get() {
      return document.body.getAttribute('data-theme') || 'neo';
    },
    apply(theme) {
      document.body.setAttribute('data-theme', theme);
      localStorage.setItem('theme', theme);
    },
    transitionTo(theme, { duration = 700 } = {}) {
      const overlay = document.getElementById('cinematic-overlay');
      if (!overlay) return this.apply(theme);
      overlay.classList.remove('hidden');
      overlay.classList.add('show');
      setTimeout(() => this.apply(theme), Math.min(duration - 100, 600));
      setTimeout(() => {
        overlay.classList.remove('show');
        overlay.classList.add('hidden');
      }, duration);
    },
    cycle() {
      const curr = this.get();
      const idx = THEMES.indexOf(curr);
      const next = THEMES[(idx + 1) % THEMES.length];
      this.transitionTo(next);
      return next;
    }
  };

  const WalletInterrogation = {
    async start({ mode = 'create', newWallet } = {}) {
      const root = document.getElementById('cinematic-overlay');
      if (!root) return;
      root.innerHTML = `
        <canvas class="cine-canvas"></canvas>
        <div class="cine-dialog">
          <div class="cine-title">${mode === 'restore' ? 'Restore Wallet' : 'Initialize Wallet'}</div>
          <div class="cine-type" id="cine-type"></div>
          <div id="cine-extra"></div>
          <div class="cine-progress"><div id="cine-progress-bar"></div></div>
          <div class="cine-cta">
            <button id="cine-skip">Skip</button>
            <button id="cine-next">Next</button>
          </div>
        </div>
      `;
      root.setAttribute('aria-hidden', 'false');
      root.classList.remove('hidden');
      setTimeout(() => root.classList.add('show'), 0);

      const canvas = root.querySelector('canvas');
      const stopFX = createFX(canvas);
      const typeEl = root.querySelector('#cine-type');
      const extraEl = root.querySelector('#cine-extra');
      const bar = root.querySelector('#cine-progress-bar');
      const btnSkip = root.querySelector('#cine-skip');
      const btnNext = root.querySelector('#cine-next');

      let step = 0;
      const steps = mode === 'restore'
        ? [
            'Welcome back. Let’s verify your recovery phrases in a secure flow.',
            'Never share your seed phrase. Ensure no screens are recorded.',
            'Enter or paste your 12/24-word phrase carefully.',
            'We will run an offline checksum. No data leaves your device.',
            'Success. Decrypting and preparing your wallet environment...'
          ]
        : [
            'Welcome. We are initializing a new Soulvan wallet in a secure enclave.',
            'Important: Your recovery phrase grants full control. Store it offline.',
            'Generating keys and deriving addresses...',
            'Showing your recovery phrase now. Write it down carefully.',
            'Finalizing wallet setup and verifying local encryption...'
          ];

      const demoMnemonic = (newWallet?.privateKey || '')
        ? newWallet.privateKey.slice(0, 48).match(/.{1,4}/g).slice(0, 12).map((s, i) => `${i+1}:${s}`).join(' ')
        : 'alpha beta gamma delta epsilon zeta eta theta iota kappa lambda mu';

      async function renderStep() {
        const pct = Math.round((step / (steps.length - 1)) * 100);
        bar.style.width = `${pct}%`;
        extraEl.innerHTML = '';
        btnNext.disabled = true;
        await typewriter(typeEl, steps[step], 24);
        btnNext.disabled = false;

        if (step === 3 && mode === 'create') {
          const pill = document.createElement('div');
          pill.className = 'cine-pill';
          pill.textContent = `Mnemonic (DEMO): ${demoMnemonic}`;
          extraEl.appendChild(pill);
        }
      }

      btnSkip.onclick = close;
      btnNext.onclick = async () => {
        if (step < steps.length - 1) {
          step++;
          await renderStep();
        } else {
          close();
        }
      };

      function close() {
        root.classList.remove('show');
        root.classList.add('hidden');
        root.setAttribute('aria-hidden', 'true');
        stopFX && stopFX();
      }

      await renderStep();
    }
  };

  const saved = localStorage.getItem('theme') || 'neo';
  document.addEventListener('DOMContentLoaded', () => CinematicTheme.apply(saved));

  window.CinematicTheme = CinematicTheme;
  window.WalletInterrogation = WalletInterrogation;
})();