# Soulvan Coin & TON Desktop Mining App

An all-in-one Windows GUI application for Soulvan Coin and TON mining and tooling.

## What's functional

- External miner execution (e.g., XMRig) with:
  - Live log streaming
  - Hashrate parsing (H/s, kH/s, MH/s, GH/s)
  - Pool, wallet/user, password, threads, and extra args fields
- Built-in demo miner (no real shares, for quick UI testing)
- Wallet stubs (create/get/send) for Soulvan and TON (replace with real SDKs/RPC when available)
- SoulvanMusic AI generates a WAV file saved under your user data folder
- PhotoAI Avatars (stub metadata)
- Cinematic onboarding and theme transitions for new wallet creation
- DAO proposals and voting (in-memory)
- Diagnostics and benchmark scripts
- Docker example for CLI/testing
- Minimal tests for miner

## Getting Started

1. Install dependencies:
   ```bash
   npm install
   ```

2. Run the app:
   ```bash
   npm start
   ```

## Configure external mining

1. Install a miner (example: XMRig for CPU/RandomX).
2. Edit `config/miners.json` to review or add presets.
3. In the app:
   - Mining tab -> Engine: External Miner
   - Select preset (XMRig)
   - Set the miner executable path (e.g., `C:\miners\xmrig\xmrig.exe`)
   - Set Pool URL (e.g., `stratum+tcp://pool.example:3333`)
   - Set Wallet (your address or username)
   - Optionally set password, threads, and extra args
   - Click Start

Logs and hashrate will stream in real-time. Click Stop to terminate.

## Notes

- TON: Traditional TON is not PoW-mined today. If you have a specific TON miner, add it as a preset in `config/miners.json`.
- Wallets: Current implementations are demo-only and not secure. Replace with real Soulvan/TON SDKs or RPC and add proper key storage.
- Security: Do NOT store real private keys in this demo without encryption and secure storage.
- Persistence: DAO and balances are in-memory for demonstration.

## Scripts

```bash
npm run diagnostics   # System info
npm run benchmark     # Hashing benchmark
npm run tests         # Minimal miner test (demo)
```