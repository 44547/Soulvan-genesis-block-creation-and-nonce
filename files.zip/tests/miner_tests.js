const assert = require('assert');
const miner = require('../mining/miner_core');

(async () => {
  console.log('Starting miner test for 2 seconds...');
  let seenStat = false;
  const id = miner.start({ coin: 'soulvan', address: 'TEST', mode: 'solo' }, (stats) => {
    seenStat = true;
    assert.ok(typeof stats.hashrate === 'number', 'hashrate should be number');
  });
  await new Promise(r => setTimeout(r, 2000));
  miner.stop(id);
  assert.ok(seenStat, 'Should have received at least one stats update');
  console.log('PASS: miner emitted stats and stopped cleanly.');
})().catch(e => {
  console.error('FAIL:', e);
  process.exit(1);
});