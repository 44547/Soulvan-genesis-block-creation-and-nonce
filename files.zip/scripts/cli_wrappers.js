const { spawn } = require('child_process');

function runCommand(cmd, args = [], options = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(cmd, args, { stdio: 'inherit', shell: true, ...options });
    child.on('error', reject);
    child.on('close', (code) => resolve({ ok: code === 0, code }));
  });
}

module.exports = { runCommand };