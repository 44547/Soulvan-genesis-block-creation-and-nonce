const crypto = require('crypto');

async function run(seconds = 5) {
  const end = Date.now() + seconds * 1000;
  let hashes = 0;
  while (Date.now() < end) {
    for (let i = 0; i < 5000; i++) {
      crypto.createHash('sha256').update(Math.random().toString()).digest('hex');
      hashes++;
    }
    await new Promise(r => setImmediate(r));
  }
  const hps = hashes / seconds;
  return { seconds, totalHashes: hashes, hashesPerSecond: Math.round(hps) };
}

if (require.main === module) {
  run(Number(process.argv[2] || 5)).then(r => console.log(JSON.stringify(r, null, 2)));
}

module.exports = { run };