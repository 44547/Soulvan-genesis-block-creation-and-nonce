const os = require('os');
const { execSync } = require('child_process');

function collect() {
  const info = {
    platform: os.platform(),
    release: os.release(),
    arch: os.arch(),
    cpus: os.cpus().slice(0, 4).map(c => ({ model: c.model, speed: c.speed })),
    cpuCount: os.cpus().length,
    totalMemGB: (os.totalmem() / (1024 ** 3)).toFixed(2),
    freeMemGB: (os.freemem() / (1024 ** 3)).toFixed(2),
    nodeVersion: process.version,
    gpu: null
  };

  try {
    if (process.platform === 'win32') {
      const out = execSync('wmic path win32_videocontroller get name').toString();
      info.gpu = out.split('\n').slice(1).map(l => l.trim()).filter(Boolean);
    } else {
      const out = execSync('lspci | grep -i vga || true').toString();
      info.gpu = out.trim().split('\n').filter(Boolean);
    }
  } catch (e) {
    try {
      const out = execSync('nvidia-smi --query-gpu=name --format=csv,noheader').toString();
      info.gpu = out.trim().split('\n');
    } catch {
      info.gpu = ['Unknown/Not detected'];
    }
  }

  return info;
}

if (require.main === module) {
  console.log(JSON.stringify(collect(), null, 2));
}

module.exports = { collect };