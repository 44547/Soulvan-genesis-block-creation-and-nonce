const crypto = require('crypto');

class MinerManager {
  constructor() {
    this.miners = new Map();
    this.counter = 1;
  }

  start(options, onStats) {
    const id = this.counter++;
    const state = {
      id,
      options,
      running: true,
      hashrate: 0,
      shares: 0,
      accepted: 0,
      rejected: 0,
      uptimeSec: 0
    };

    const startTime = Date.now();
    let hashesThisSec = 0;
    let lastTick = Date.now();

    const loop = () => {
      if (!state.running) return;
      for (let i = 0; i < 5000; i++) {
        const data = `${options.coin}|${options.address}|${Math.random()}|${Date.now()}`;
        crypto.createHash('sha256').update(data).digest('hex');
        hashesThisSec++;
      }
      const now = Date.now();
      if (now - lastTick >= 1000) {
        state.hashrate = hashesThisSec;
        state.uptimeSec = Math.floor((now - startTime) / 1000);
        if (Math.random() < 0.3) {
          state.shares += 1;
          if (Math.random() < 0.9) state.accepted += 1; else state.rejected += 1;
        }
        hashesThisSec = 0;
        lastTick = now;
        onStats && onStats({
          hashrate: state.hashrate,
          shares: state.shares,
          accepted: state.accepted,
          rejected: state.rejected,
          uptimeSec: state.uptimeSec
        });
      }
      state._raf = setImmediate(loop);
    };

    loop();
    this.miners.set(id, state);
    return id;
  }

  stop(id) {
    const state = this.miners.get(id);
    if (state) {
      state.running = false;
      if (state._raf) clearImmediate(state._raf);
      this.miners.delete(id);
    }
  }
}

const manager = new MinerManager();

module.exports = {
  start: (options, onStats) => manager.start(options, onStats),
  stop: (id) => manager.stop(id)
};