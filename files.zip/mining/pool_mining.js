let poolConfig = { poolUrl: '', user: '', password: 'x' };

module.exports = {
  configure: (cfg) => {
    poolConfig = { ...poolConfig, ...cfg };
    return { ok: true, poolConfig };
  },
  getConfig: () => poolConfig
};