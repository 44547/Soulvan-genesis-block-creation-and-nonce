let soloConfig = { nodeUrl: '', rpcUser: '', rpcPassword: '' };

module.exports = {
  configure: (cfg) => {
    soloConfig = { ...soloConfig, ...cfg };
    return { ok: true, soloConfig };
  },
  getConfig: () => soloConfig
};