const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');

const MINERS_CFG = (() => {
  try {
    const p = path.join(process.cwd(), 'config', 'miners.json');
    return JSON.parse(fs.readFileSync(p, 'utf8'));
  } catch {
    return { presets: [] };
  }
})();

const PROCS = new Map();
let COUNTER = 1;

function unitToHps(num, unit) {
  const m = unit.toLowerCase();
  if (m.includes('gh')) return num * 1e9;
  if (m.includes('mh')) return num * 1e6;
  if (m.includes('kh')) return num * 1e3;
  return num;
}

function parseHashrate(line, hashrateRegexes = []) {
  for (const r of hashrateRegexes) {
    const re = new RegExp(r, 'i');
    const m = line.match(re);
    if (m && m[1]) {
      const val = parseFloat(m[1]);
      const unit = m[2] || 'H/s';
      return unitToHps(val, unit);
    }
  }
  const generic = line.match(/([0-9.]+)\s*(H\/s|kH\/s|MH\/s|GH\/s)/i);
  if (generic) return unitToHps(parseFloat(generic[1]), generic[2]);
  return null;
}

function formatArgs(template, vars) {
  return template
    .replaceAll('{POOL_URL}', vars.poolUrl || '')
    .replaceAll('{WALLET}', vars.wallet || '')
    .replaceAll('{PASSWORD}', vars.password ?? 'x')
    .replaceAll('{THREADS}', String(vars.threads ?? ''))
    .trim()
    .split(/\s+/)
    .filter(Boolean);
}

function startExternal({ presetId, exePath, poolUrl, wallet, password = 'x', threads, extraArgs = '' }, onEvent) {
  const id = COUNTER++;
  const preset = (MINERS_CFG.presets || []).find(p => p.id === presetId) || {};
  const hashrateRegexes = preset.hashrateRegexes || [];
  const args = preset.argsTemplate
    ? formatArgs(preset.argsTemplate + (extraArgs ? ` ${extraArgs}` : ''), { poolUrl, wallet, password, threads })
    : (extraArgs ? extraArgs.split(/\s+/) : []);

  const child = spawn(exePath, args, {
    cwd: path.dirname(exePath),
    windowsHide: true,
    shell: false,
    env: { ...process.env }
  });

  const state = { id, exePath, args, startTime: Date.now(), hashrate: 0, shares: 0, accepted: 0, rejected: 0 };
  PROCS.set(id, { child, state, hashrateRegexes });

  function handle(line) {
    onEvent && onEvent({ type: 'log', id, line });
    const hr = parseHashrate(line, hashrateRegexes);
    if (hr) {
      state.hashrate = hr;
      onEvent && onEvent({
        type: 'stats',
        id,
        hashrate: state.hashrate,
        shares: state.shares,
        accepted: state.accepted,
        rejected: state.rejected,
        uptimeSec: Math.floor((Date.now() - state.startTime) / 1000)
      });
    }
    if (/share\s+accepted/i.test(line)) { state.accepted++; state.shares++; }
    if (/share\s+rejected/i.test(line)) { state.rejected++; state.shares++; }
  }

  child.stdout.on('data', (d) => String(d).split(/\r?\n/).forEach(s => s && handle(s)));
  child.stderr.on('data', (d) => String(d).split(/\r?\n/).forEach(s => s && handle(s)));
  child.on('close', (code) => {
    onEvent && onEvent({ type: 'exit', id, code });
    PROCS.delete(id);
  });
  child.on('error', (err) => {
    onEvent && onEvent({ type: 'error', id, error: String(err) });
    PROCS.delete(id);
  });

  onEvent && onEvent({ type: 'start', id, exePath, args });

  return id;
}

function stopExternal(id) {
  const rec = PROCS.get(id);
  if (!rec) return false;
  try {
    rec.child.kill('SIGINT');
    setTimeout(() => rec.child.kill('SIGKILL'), 1500);
  } catch {}
  PROCS.delete(id);
  return true;
}

module.exports = { startExternal, stopExternal, MINERS_CFG };