// Minimal TON demo integration (no external deps). In real use, integrate tonweb or @ton/ton.
const crypto = require('crypto');

const balances = new Map(); // address -> number

function createWallet() {
  const privateKey = crypto.randomBytes(32).toString('hex');
  const address = 'EQ' + crypto.createHash('sha256').update(privateKey).digest('hex').slice(0, 46);
  balances.set(address, (Math.random() * 5).toFixed(4) * 1);
  return { address, privateKey };
}

function getBalance(address) {
  const bal = balances.get(address) || 0;
  return { coin: 'ton', address, balance: bal };
}

function send(from, to, amount) {
  amount = Number(amount);
  const fromBal = balances.get(from) || 0;
  if (fromBal < amount) return { ok: false, error: 'Insufficient balance (demo)' };
  balances.set(from, fromBal - amount);
  balances.set(to, (balances.get(to) || 0) + amount);
  return { ok: true, txid: 'TON-' + crypto.randomBytes(12).toString('hex') };
}

module.exports = { createWallet, getBalance, send };