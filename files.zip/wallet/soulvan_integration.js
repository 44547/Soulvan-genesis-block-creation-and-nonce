const crypto = require('crypto');

const balances = new Map(); // address -> number

function createWallet() {
  const privateKey = crypto.randomBytes(32).toString('hex');
  const address = crypto.createHash('ripemd160').update(privateKey).digest('hex');
  balances.set(address, (Math.random() * 10).toFixed(6) * 1);
  return { address, privateKey };
}

function getBalance(address) {
  const bal = balances.get(address) || 0;
  return { coin: 'soulvan', address, balance: bal };
}

function send(from, to, amount) {
  amount = Number(amount);
  const fromBal = balances.get(from) || 0;
  if (fromBal < amount) return { ok: false, error: 'Insufficient balance (demo)' };
  balances.set(from, fromBal - amount);
  balances.set(to, (balances.get(to) || 0) + amount);
  return { ok: true, txid: crypto.randomBytes(16).toString('hex') };
}

module.exports = { createWallet, getBalance, send };