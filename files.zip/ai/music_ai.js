const fs = require('fs');
const path = require('path');

// Minimal WAV writer for a mono 16-bit PCM file
function writeWavPCM16(filePath, samples, sampleRate = 22050) {
  const numChannels = 1;
  const bitsPerSample = 16;
  const byteRate = sampleRate * numChannels * bitsPerSample / 8;
  const blockAlign = numChannels * bitsPerSample / 8;
  const dataSize = samples.length * 2;
  const buffer = Buffer.alloc(44 + dataSize);

  buffer.write('RIFF', 0);
  buffer.writeUInt32LE(36 + dataSize, 4);
  buffer.write('WAVE', 8);
  buffer.write('fmt ', 12);
  buffer.writeUInt32LE(16, 16);
  buffer.writeUInt16LE(1, 20);
  buffer.writeUInt16LE(numChannels, 22);
  buffer.writeUInt32LE(sampleRate, 24);
  buffer.writeUInt32LE(byteRate, 28);
  buffer.writeUInt16LE(blockAlign, 32);
  buffer.writeUInt16LE(bitsPerSample, 34);
  buffer.write('data', 36);
  buffer.writeUInt32LE(dataSize, 40);

  for (let i = 0; i < samples.length; i++) {
    let s = Math.max(-1, Math.min(1, samples[i]));
    buffer.writeInt16LE(Math.round(s * 32767), 44 + i * 2);
  }
  fs.writeFileSync(filePath, buffer);
}

async function generate(prompt = '', lengthSec = 8) {
  const sampleRate = 22050;
  const totalSamples = Math.min(60, lengthSec) * sampleRate;
  const hash = Array.from(prompt).reduce((a, c) => (a + c.charCodeAt(0)) % 1000, 0);
  const baseFreq = 220 + (hash % 440);
  const samples = new Float32Array(totalSamples);
  for (let i = 0; i < totalSamples; i++) {
    const t = i / sampleRate;
    const vibrato = Math.sin(2 * Math.PI * 5 * t) * 3;
    const freq = baseFreq + vibrato;
    samples[i] = 0.2 * Math.sin(2 * Math.PI * freq * t);
  }

  const outDir = path.join(appDataPath(), 'music');
  fs.mkdirSync(outDir, { recursive: true });
  const filePath = path.join(outDir, `sv_music_${Date.now()}.wav`);
  writeWavPCM16(filePath, samples, sampleRate);

  const previewPoints = [];
  for (let i = 0; i < Math.min(200, samples.length); i += Math.floor(sampleRate / 100)) {
    previewPoints.push(samples[i]);
  }

  return {
    ok: true,
    prompt,
    lengthSec: Math.min(60, lengthSec),
    sampleRate,
    filePath,
    previewPoints
  };
}

function appDataPath() {
  const base = process.env.APPDATA || (process.platform === 'darwin'
    ? path.join(process.env.HOME || '.', 'Library', 'Application Support')
    : path.join(process.env.HOME || '.', '.local', 'share'));
  const dir = path.join(base, 'soulvancoin-miner-app');
  return dir;
}

module.exports = { generate };