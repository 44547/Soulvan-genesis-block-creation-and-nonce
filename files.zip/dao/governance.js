let proposals = [];
let counter = 1;

function listProposals() {
  return proposals;
}

function createProposal(title, description) {
  const p = {
    id: counter++,
    title,
    description,
    votes: { yes: 0, no: 0 },
    createdAt: new Date().toISOString()
  };
  proposals = [p, ...proposals];
  return p;
}

function vote(proposalId, choice) {
  const p = proposals.find(x => x.id === proposalId);
  if (!p) return { ok: false, error: 'Not found' };
  if (choice === 'yes') p.votes.yes++;
  else if (choice === 'no') p.votes.no++;
  else return { ok: false, error: 'Invalid choice' };
  return { ok: true, proposal: p };
}

module.exports = { listProposals, createProposal, vote };