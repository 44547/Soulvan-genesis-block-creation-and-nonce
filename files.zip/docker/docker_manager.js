const { spawn } = require('child_process');

function build(tag = 'soulvancoin-app:dev') {
  return new Promise((resolve) => {
    const child = spawn('docker', ['build', '-f', 'docker/Dockerfile.example', '-t', tag, '.'], { stdio: 'inherit', shell: true });
    child.on('close', code => resolve({ ok: code === 0, code }));
    child.on('error', err => resolve({ ok: false, error: String(err) }));
  });
}

function run(tag = 'soulvancoin-app:dev', args = []) {
  return new Promise((resolve) => {
    const child = spawn('docker', ['run', '--rm', tag, ...args], { stdio: 'inherit', shell: true });
    child.on('close', code => resolve({ ok: code === 0, code }));
    child.on('error', err => resolve({ ok: false, error: String(err) }));
  });
}

module.exports = { build, run };