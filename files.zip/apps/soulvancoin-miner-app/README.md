# Soulvan Coin & TON Desktop Mining App

## Download for Windows

- Latest stable installer:  
  [Soulvan-Miner-Setup.exe](https://github.com/44547/soulvan-coin-core/releases/latest/download/Soulvan-Miner-Setup.exe)

- Version-specific installer (replace X.Y.Z with the release tag):  
  [Soulvan-Miner-Setup-X.Y.Z.exe](https://github.com/44547/soulvan-coin-core/releases/download/vX.Y.Z/Soulvan-Miner-Setup-X.Y.Z.exe)

> The installer is built automatically when a new tag (e.g., `v0.4.1`) is pushed.

### Local build (optional)

```bash
cd apps/soulvancoin-miner-app
npm install
npm run dist
# Output: dist/Soulvan-Miner-Setup-<version>.exe
```

---

## Automatic version bumping on tag

Two mechanisms ensure version alignment:

1) Build-time alignment (no repo change)  
The Windows Release workflow extracts the tag (e.g., `v0.4.1`) and runs:

```bash
npm version 0.4.1 --no-git-tag-version
```

This makes the built artifact version match the tag.

2) Repo sync PR (optional but enabled)  
Workflow `.github/workflows/bump-version-on-tag.yml` opens a PR updating
`apps/soulvancoin-miner-app/package.json` to match the tag so the repo stays in sync.

---

## Code signing (placeholders)

- Windows (NSIS/EXE)
  - Set secrets in repository settings:
    - `WIN_CSC_LINK`: base64 or URL to `.p12/.pfx`
    - `WIN_CSC_KEY_PASSWORD`: certificate password
  - electron-builder will sign automatically if these env vars are present.

- macOS (DMG)
  - Set secrets (only needed if you enable mac builds):
    - `MAC_CSC_LINK`: base64 or URL to Apple Developer cert
    - `MAC_CSC_KEY_PASSWORD`
    - `APPLE_ID` (Apple ID email)
    - `APPLE_APP_SPECIFIC_PASSWORD`
    - `APPLE_TEAM_ID`
  - Build uses hardened runtime and entitlements at `build/entitlements.mac.plist`.

---

## Optional Linux/macOS builds (manual)

A separate workflow (`release-cross.yml`) can produce:
- Linux: `.deb` and `.AppImage`
- macOS: `.dmg`

They are disabled by default and only run when manually triggered:

1) Go to GitHub Actions → “Cross-platform builds (manual)”
2) Click “Run workflow”
3) Select:
   - enable_linux: true (for .deb/.AppImage)
   - enable_macos: true (for .dmg)
   - version (optional): set to `0.4.1` to override package.json during this build

Artifacts will appear under the run’s “Artifacts” section.
