// Demo "avatar generation": copy the input image to a styled filename so it can be previewed.
const fs = require('fs');
const path = require('path');

function generateAvatar(imagePath, style = 'cyberpunk') {
  try {
    if (!imagePath) return { ok: false, error: 'imagePath required' };
    if (!fs.existsSync(imagePath)) return { ok: false, error: 'imagePath not found' };
    const dir = path.dirname(imagePath);
    const ext = path.extname(imagePath) || '.png';
    const base = path.basename(imagePath, ext);
    const outFile = path.join(dir, `${base}.${style}.avatar${ext}`);
    // For demo purposes, copy the image to the output path so the preview exists.
    fs.copyFileSync(imagePath, outFile);
    return { ok: true, style, input: imagePath, output: outFile, note: 'Demo stub: copied input to preview output.' };
  } catch (e) {
    return { ok: false, error: String(e) };
  }
}

module.exports = { generateAvatar };