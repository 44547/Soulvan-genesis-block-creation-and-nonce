const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');

const MINERS_CFG = (() => {
  const tryPaths = [
    path.join(process.cwd(), 'apps', 'soulvancoin-miner-app', 'config', 'miners.json'),
    path.join(process.cwd(), 'config', 'miners.json')
  ];
  for (const p of tryPaths) {
    try {
      return JSON.parse(fs.readFileSync(p, 'utf8'));
    } catch {}
  }
  return { presets: [] };
})();

const PROCS = new Map();
let COUNTER = 1;

function unitToHps(num, unit) {
  const m = (unit || '').toLowerCase();
  if (m.includes('gsol')) return num * 1e9;
  if (m.includes('msol')) return num * 1e6;
  if (m.includes('ksol')) return num * 1e3;
  if (m.includes('gh')) return num * 1e9;
  if (m.includes('mh')) return num * 1e6;
  if (m.includes('kh')) return num * 1e3;
  return num;
}

const GENERIC_HASHRATE_RES = [
  /Total\s+Speed\s*[:=]\s*([0-9.]+)\s*(H\/s|KH\/s|MH\/s|GH\/s|Sol\/s|kSol\/s|MSol\/s|GSol\/s)/i,
  /Total\s+Hashrate\s*[:=]\s*([0-9.]+)\s*(H\/s|KH\/s|MH\/s|GH\/s)/i,
  /Hashrate.*?[:=]\s*([0-9.]+)\s*(H\/s|KH\/s|MH\/s|GH\/s)/i,
  /Average\s+speed.*?[:=]\s*([0-9.]+)\s*(H\/s|KH\/s|MH\/s|GH\/s)/i,
  /speed.*?[:=]\s*([0-9.]+)\s*(H\/s|KH\/s|MH\/s|GH\/s)/i,
  /GPU\s+#\d+[^:]*:\s*([0-9.]+)\s*(H\/s|KH\/s|MH\/s|GH\/s)/i
];

function parseHashrate(line, hashrateRegexes = []) {
  for (const r of hashrateRegexes) {
    const re = new RegExp(r, 'i');
    const m = line.match(re);
    if (m && m[1]) {
      // Some presets might capture hashrate in group 1 vs 2; normalize
      const val = parseFloat(m[1] ?? m[2]);
      const unit = m[2] && isNaN(Number(m[2])) ? m[2] : (m[3] || 'H/s');
      return unitToHps(val, unit);
    }
  }
  for (const re of GENERIC_HASHRATE_RES) {
    const m = line.match(re);
    if (m && m[1]) {
      const val = parseFloat(m[1] ?? m[2]);
      const unit = m[2] && isNaN(Number(m[2])) ? m[2] : (m[3] || 'H/s');
      return unitToHps(val, unit);
    }
  }
  return null;
}

function formatArgs(template, vars) {
  return template
    .replace(/\{([A-Z0-9_]+)\}/gi, (_, k) => {
      const keyLower = k.toLowerCase();
      return vars[keyLower] ?? vars[k] ?? '';
    })
    .trim()
    .split(/\s+/)
    .filter(Boolean);
}

function startExternal(opts, onEvent) {
  const {
    presetId, exePath, poolUrl, wallet, password = 'x',
    threads, extraArgs = '', algo = '', workername = ''
  } = opts;

  const id = COUNTER++;
  const preset = (MINERS_CFG.presets || []).find(p => p.id === presetId) || {};
  const hashrateRegexes = preset.hashrateRegexes || [];

  const vars = {
    pool_url: poolUrl,
    wallet,
    password,
    threads,
    algo,
    workername
  };

  const argvFromTemplate = preset.argsTemplate
    ? formatArgs(preset.argsTemplate + (extraArgs ? ` ${extraArgs}` : ''), vars)
    : (extraArgs ? extraArgs.trim().split(/\s+/) : []);

  const child = spawn(exePath, argvFromTemplate, {
    cwd: path.dirname(exePath),
    windowsHide: true,
    shell: false,
    env: { ...process.env }
  });

  const state = { id, exePath, args: argvFromTemplate, startTime: Date.now(), hashrate: 0, shares: 0, accepted: 0, rejected: 0 };
  PROCS.set(id, { child, state, hashrateRegexes });

  function emitStats() {
    onEvent && onEvent({
      type: 'stats',
      id,
      hashrate: state.hashrate,
      shares: state.shares,
      accepted: state.accepted,
      rejected: state.rejected,
      uptimeSec: Math.floor((Date.now() - state.startTime) / 1000)
    });
  }

  function handle(line) {
    onEvent && onEvent({ type: 'log', id, line });
    const hr = parseHashrate(line, hashrateRegexes);
    if (hr) {
      state.hashrate = hr;
      emitStats();
    }
    if (/accepted/i.test(line) && /share/i.test(line)) { state.accepted++; state.shares++; emitStats(); }
    if (/rejected/i.test(line) && /share/i.test(line)) { state.rejected++; state.shares++; emitStats(); }
  }

  child.stdout.on('data', (d) => String(d).split(/\r?\n/).forEach(s => s && handle(s)));
  child.stderr.on('data', (d) => String(d).split(/\r?\n/).forEach(s => s && handle(s)));
  child.on('close', (code) => {
    onEvent && onEvent({ type: 'exit', id, code });
    PROCS.delete(id);
  });
  child.on('error', (err) => {
    onEvent && onEvent({ type: 'error', id, error: String(err) });
    PROCS.delete(id);
  });

  onEvent && onEvent({ type: 'start', id, exePath, args: argvFromTemplate });

  return id;
}

function stopExternal(id) {
  const rec = PROCS.get(id);
  if (!rec) return false;
  try {
    rec.child.kill('SIGINT');
    setTimeout(() => rec.child.kill('SIGKILL'), 1500);
  } catch {}
  PROCS.delete(id);
  return true;
}

module.exports = { startExternal, stopExternal, MINERS_CFG };