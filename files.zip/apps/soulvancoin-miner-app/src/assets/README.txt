Place your title image here as "title.png".
Recommended size/aspect: square (e.g., 256x256). It will render at 28x28 next to the app title.
Path referenced by the navbar: src/assets/title.png