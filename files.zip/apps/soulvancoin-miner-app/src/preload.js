const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  mining: {
    presets: () => ipcRenderer.invoke('mining:presets'),
    start: (options) => ipcRenderer.invoke('mining:start', options),
    stop: (id, external) => ipcRenderer.invoke('mining:stop', { id, external }),
    setMode: (mode, options) => ipcRenderer.invoke('mining:mode', { mode, options }),
    onStats: (cb) => {
      const listener = (_e, data) => cb(data);
      ipcRenderer.on('mining:stats', listener);
      return () => ipcRenderer.removeListener('mining:stats', listener);
    },
    onLog: (cb) => {
      const listener = (_e, data) => cb(data);
      ipcRenderer.on('mining:log', listener);
      return () => ipcRenderer.removeListener('mining:log', listener);
    },
    onEvent: (cb) => {
      const listener = (_e, data) => cb(data);
      ipcRenderer.on('mining:event', listener);
      return () => ipcRenderer.removeListener('mining:event', listener);
    }
  },
  wallet: {
    getBalance: (coin, address) => ipcRenderer.invoke('wallet:getBalance', { coin, address }),
    create: (coin) => ipcRenderer.invoke('wallet:create', { coin }),
    send: (coin, from, to, amount) => ipcRenderer.invoke('wallet:send', { coin, from, to, amount })
  },
  ai: {
    musicGenerate: (prompt, lengthSec) => ipcRenderer.invoke('ai:music:generate', { prompt, lengthSec }),
    photoAvatar: (imagePath, style) => ipcRenderer.invoke('ai:photo:avatar', { imagePath, style })
  },
  files: {
    openDialog: (filters) => ipcRenderer.invoke('file:openDialog', { filters })
  },
  dao: {
    list: () => ipcRenderer.invoke('dao:list'),
    vote: (proposalId, choice) => ipcRenderer.invoke('dao:vote', { proposalId, choice }),
    create: (title, description) => ipcRenderer.invoke('dao:create', { title, description })
  },
  scripts: {
    diagnostics: () => ipcRenderer.invoke('scripts:diagnostics'),
    benchmark: (seconds) => ipcRenderer.invoke('scripts:benchmark', { seconds })
  },
  docker: {
    build: (tag) => ipcRenderer.invoke('docker:build', { tag }),
    run: (tag, args) => ipcRenderer.invoke('docker:run', { tag, args })
  }
});