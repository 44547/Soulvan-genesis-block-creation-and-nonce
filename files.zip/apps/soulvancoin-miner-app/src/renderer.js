// Helper: tabs/state remain same as before (omitted for brevity)
const tabs = [
  { key: 'mining', label: 'Mining' },
  { key: 'wallet', label: 'Wallet' },
  { key: 'musicai', label: 'SoulvanMusic AI' },
  { key: 'photoai', label: 'PhotoAI Avatars' },
  { key: 'dao', label: 'DAO Governance' },
  { key: 'scripts', label: 'Utility Scripts' },
  { key: 'tests', label: 'Tests' },
  { key: 'docker', label: 'Docker' }
];

let selected = 'mining';

let miningState = {
  runningId: null,
  external: false,
  stats: { hashrate: 0, shares: 0, accepted: 0, rejected: 0, uptimeSec: 0 },
  coin: 'soulvan',
  mode: 'solo',
  address: '',
  engine: 'external',
  exePath: '',
  presetId: 'xmrig',
  poolUrl: '',
  password: 'x',
  threads: '',
  extraArgs: '',
  algo: "",
  workername: "",
  logs: []
};

let walletState = {
  coin: 'soulvan',
  address: '',
  balance: null,
  newWallet: null,
  send: { to: '', amount: '' }
};

let daoState = { proposals: [] };
let testOutput = '';
let diagOutput = '';
let benchOutput = '';
let presets = { presets: [] };

function toFileUrl(p) {
  if (!p) return '';
  return 'file:///' + p.replace(/\\/g, '/');
}

function render() {
  const root = document.getElementById('root');
  root.innerHTML = `
    <div class="navbar">
      <div class="brand">
        <img class="brand-logo" src="./assets/title.png" alt="Soulvan Miner" onerror="this.style.display='none'"/>
        <span class="brand-title">Soulvan Miner</span>
      </div>
      ${tabs.map(tab => `
        <span class="tab${selected === tab.key ? ' selected' : ''}" data-key="${tab.key}">
          ${tab.label}
        </span>`).join('')}
      <span style="margin-left:auto"></span>
      <button id="theme-cycle" title="Cycle Cinematic Theme">Theme</button>
    </div>
    <div class="tab-content">
      ${getTabContent(selected)}
    </div>
  `;
  Array.from(document.querySelectorAll('.tab')).forEach(el => {
    el.onclick = () => { selected = el.dataset.key; render(); };
  });
  document.getElementById('theme-cycle').onclick = () => {
    const next = window.CinematicTheme.cycle();
    console.log('Theme changed to:', next);
  };
  wireTab(selected);
}

function getTabContent(tab) {
  switch(tab) {
    case 'mining': return miningTab();
    case 'wallet': return walletTab();
    case 'musicai': return musicAITab();
    case 'photoai': return photoAITab();
    case 'dao': return daoTab();
    case 'scripts': return scriptsTab();
    case 'tests': return testsTab();
    case 'docker': return dockerTab();
    default: return `<p>Coming soon.</p>`;
  }
}

function musicAITab() {
  return `
    <div class="card">
      <h3>SoulvanMusic AI</h3>
      <textarea id="music-prompt" rows="3" placeholder="Describe the music to generate (style, mood, tempo)"></textarea>
      <div class="row">
        <input id="music-length" type="number" value="8" min="1" max="60" /> <span>seconds</span>
        <button id="music-generate">Generate</button>
      </div>
      <div id="music-result" class="mono"></div>
      <audio id="music-audio" controls style="width:100%;margin-top:8px;display:none;"></audio>
    </div>
  `;
}

function photoAITab() {
  return `
    <div class="card">
      <h3>PhotoAI Avatars</h3>
      <div class="row">
        <input id="photo-path" placeholder="Path to image file" size="50" />
        <select id="photo-style">
          <option value="cyberpunk">Cyberpunk</option>
          <option value="cartoon">Cartoon</option>
          <option value="oil-painting">Oil Painting</option>
        </select>
        <button id="photo-choose">Choose...</button>
        <button id="photo-generate">Generate Avatar</button>
      </div>
      <div id="photo-result" class="mono"></div>
      <div style="margin-top:8px;">
        <img id="photo-preview" alt="Avatar preview" style="max-width:100%;max-height:320px;display:none;border:1px solid var(--border);border-radius:8px;"/>
      </div>
    </div>
  `;
}

// The remaining tabs (mining, wallet, dao, scripts, tests, docker) remain identical to your current version,
// so they are omitted here for brevity, except for wireTab bindings below.

function wireTab(tab) {
  if (tab === 'musicai') {
    document.getElementById('music-generate').onclick = async () => {
      const prompt = document.getElementById('music-prompt').value;
      const lengthSec = Number(document.getElementById('music-length').value);
      const res = await window.api.ai.musicGenerate(prompt, lengthSec);
      const link = res.filePath ? `Saved to: ${res.filePath}` : '';
      document.getElementById('music-result').textContent = JSON.stringify({ ...res, note: link }, null, 2);
      const audio = document.getElementById('music-audio');
      if (res.filePath && audio) {
        audio.src = toFileUrl(res.filePath);
        audio.style.display = 'block';
        audio.load();
      }
    };
  }

  if (tab === 'photoai') {
    document.getElementById('photo-choose').onclick = async () => {
      const r = await window.api.files.openDialog([{ name: 'Images', extensions: ['png','jpg','jpeg','webp'] }]);
      if (!r.canceled && r.path) {
        const input = document.getElementById('photo-path');
        input.value = r.path;
      }
    };
    document.getElementById('photo-generate').onclick = async () => {
      const imagePath = document.getElementById('photo-path').value;
      const style = document.getElementById('photo-style').value;
      const res = await window.api.ai.photoAvatar(imagePath, style);
      document.getElementById('photo-result').textContent = JSON.stringify(res, null, 2);
      const img = document.getElementById('photo-preview');
      if (res.ok && res.output && img) {
        img.src = toFileUrl(res.output);
        img.style.display = 'block';
      }
    };
  }

  // Re-bind for other tabs by calling the existing code you already have in your file.
  // (Keep your current implementations for mining/wallet/dao/scripts/tests/docker).
}

window.onload = () => {
  window.api.mining.presets().then(p => { presets = p; render(); });
};