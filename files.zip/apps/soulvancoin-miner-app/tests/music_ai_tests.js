const assert = require('assert');
const fs = require('fs');
const path = require('path');
const musicAI = require('../ai/music_ai');

(async () => {
  const res = await musicAI.generate('test-tone', 2);
  assert.ok(res.ok, 'music generation should be ok');
  assert.ok(res.filePath && fs.existsSync(res.filePath), 'wav file should exist');
  const buf = fs.readFileSync(res.filePath);
  // Check RIFF/WAVE header
  assert.strictEqual(buf.toString('ascii', 0, 4), 'RIFF', 'WAV must start with RIFF');
  assert.strictEqual(buf.toString('ascii', 8, 12), 'WAVE', 'WAV must contain WAVE header');
  console.log('PASS: music_ai generated WAV with valid header at', res.filePath);
})().catch(e => { console.error('FAIL:', e); process.exit(1); });