const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const photoAI = require('../ai/photo_ai');

// Minimal 1x1 PNG
const PNG_1x1_BASE64 = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMB/Yo3hNcAAAAASUVORK5CYII=';

(async () => {
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'sv-photo-'));
  const input = path.join(tmpDir, 'in.png');
  fs.writeFileSync(input, Buffer.from(PNG_1x1_BASE64, 'base64'));

  const res = await photoAI.generateAvatar(input, 'cyberpunk');
  assert.ok(res.ok, 'photo avatar generation should be ok');
  assert.ok(res.output && fs.existsSync(res.output), 'output file should exist');
  const stat = fs.statSync(res.output);
  assert.ok(stat.size > 0, 'output file should not be empty');
  console.log('PASS: photo_ai produced preview copy at', res.output);
})().catch(e => { console.error('FAIL:', e); process.exit(1); });