const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');

// Built-in demo miner
const minerCore = require('./mining/miner_core');
const poolMining = require('./mining/pool_mining');
const soloMining = require('./mining/solo_mining');
// External miner orchestrator
const extMiner = require('./mining/external_miners');

// Wallets
const soulvanWallet = require('./wallet/soulvan_integration');
const tonWallet = require('./wallet/ton_integration');

// AI
const musicAI = require('./ai/music_ai');
const photoAI = require('./ai/photo_ai');

// DAO and Scripts
const governance = require('./dao/governance');
const diagnostics = require('./scripts/diagnostics');
const benchmark = require('./scripts/benchmark');
const dockerMgr = require('./docker/docker_manager');

let mainWindow;

function createWindow () {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 860,
    webPreferences: {
      preload: path.join(__dirname, 'src', 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  mainWindow.loadFile(path.join(__dirname, 'src', 'index.html'));
}

app.whenReady().then(() => {
  createWindow();

  // Mining IPC - supports built-in demo and external miners
  ipcMain.handle('mining:start', async (_e, options) => {
    if (options.engine === 'external') {
      const id = extMiner.startExternal(options, (evt) => {
        if (!mainWindow || mainWindow.isDestroyed()) return;
        if (evt.type === 'stats') mainWindow.webContents.send('mining:stats', evt);
        if (evt.type === 'log') mainWindow.webContents.send('mining:log', evt);
        if (evt.type === 'start' || evt.type === 'exit' || evt.type === 'error') {
          mainWindow.webContents.send('mining:event', evt);
        }
      });
      return { id, external: true };
    }
    const id = minerCore.start(options, (stats) => {
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send('mining:stats', { id, ...stats });
      }
    });
    return { id, external: false };
  });

  ipcMain.handle('mining:stop', async (_e, { id, external }) => {
    if (external) {
      extMiner.stopExternal(id);
      return { stopped: true };
    }
    minerCore.stop(id);
    return { stopped: true };
  });

  ipcMain.handle('mining:mode', async (_e, { mode, options }) => {
    if (mode === 'pool') return poolMining.configure(options || {});
    if (mode === 'solo') return soloMining.configure(options || {});
    return { ok: false, error: 'Unknown mode' };
  });

  ipcMain.handle('mining:presets', async () => {
    return extMiner.MINERS_CFG;
  });

  // Wallet IPC
  ipcMain.handle('wallet:getBalance', async (_e, { coin, address }) => {
    if (coin === 'soulvan') return soulvanWallet.getBalance(address);
    if (coin === 'ton') return tonWallet.getBalance(address);
    return { ok: false, error: 'Unknown coin' };
  });

  ipcMain.handle('wallet:create', async (_e, { coin }) => {
    if (coin === 'soulvan') return soulvanWallet.createWallet();
    if (coin === 'ton') return tonWallet.createWallet();
    return { ok: false, error: 'Unknown coin' };
  });

  ipcMain.handle('wallet:send', async (_e, { coin, from, to, amount }) => {
    if (coin === 'soulvan') return soulvanWallet.send(from, to, amount);
    if (coin === 'ton') return tonWallet.send(from, to, amount);
    return { ok: false, error: 'Unknown coin' };
  });

  // AI IPC
  ipcMain.handle('ai:music:generate', async (_e, { prompt, lengthSec }) => {
    return musicAI.generate(prompt, lengthSec);
  });

  ipcMain.handle('ai:photo:avatar', async (_e, { imagePath, style }) => {
    return photoAI.generateAvatar(imagePath, style);
  });

  // Files / Dialogs (for previews)
  ipcMain.handle('file:openDialog', async (_e, { filters }) => {
    const res = await dialog.showOpenDialog(mainWindow, {
      properties: ['openFile'],
      filters: filters || [{ name: 'Images', extensions: ['png', 'jpg', 'jpeg', 'webp'] }]
    });
    if (res.canceled || !res.filePaths.length) return { canceled: true };
    return { canceled: false, path: res.filePaths[0] };
  });

  // DAO IPC
  ipcMain.handle('dao:list', async () => governance.listProposals());
  ipcMain.handle('dao:vote', async (_e, { proposalId, choice }) => governance.vote(proposalId, choice));
  ipcMain.handle('dao:create', async (_e, { title, description }) => governance.createProposal(title, description));

  // Scripts IPC
  ipcMain.handle('scripts:diagnostics', async () => diagnostics.collect());
  ipcMain.handle('scripts:benchmark', async (_e, { seconds }) => benchmark.run(seconds));

  // Docker IPC
  ipcMain.handle('docker:build', async (_e, { tag }) => dockerMgr.build(tag));
  ipcMain.handle('docker:run', async (_e, { tag, args }) => dockerMgr.run(tag, args));

  app.on('activate', function () {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', function () {
  if (process.platform !== 'darwin') app.quit();
});